package com.example.coolproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class FriendPageActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_search:
                    //mTextMessage.setText(R.string.title_search);

                    Intent a = new Intent(FriendPageActivity.this, SearchActivity.class);
                    startActivity(a);
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);

                    Intent b = new Intent(FriendPageActivity.this, MainActivity.class);
                    startActivity(b);
                    return true;
                case R.id.navigation_profile:
                    //mTextMessage.setText(R.string.title_profile);

                    Intent c = new Intent(FriendPageActivity.this, ProfileActivity.class);
                    startActivity(c);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_page);

        BottomNavigationView bottomnav = (BottomNavigationView) findViewById(R.id.navigation);
        bottomnav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = bottomnav.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(false);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
