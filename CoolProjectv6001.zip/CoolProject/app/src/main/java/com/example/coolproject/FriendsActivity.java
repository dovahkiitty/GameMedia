package com.example.coolproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FriendsActivity extends AppCompatActivity implements FriendsAdapter.ListItemClickListener {

    private TextView mTextMessage;
    private FriendsAdapter FriendsAdapter;
    private RecyclerView fNumbersList;

    ArrayList<Users> list;


    private DatabaseReference mDatabase;
    private DatabaseReference nDatabase;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_search:
                    //mTextMessage.setText(R.string.title_search);

                    Intent a = new Intent(FriendsActivity.this, SearchActivity.class);
                    startActivity(a);
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);

                    Intent b = new Intent(FriendsActivity.this, MainActivity.class);
                    startActivity(b);
                    return true;
                case R.id.navigation_profile:
                    //mTextMessage.setText(R.string.title_profile);

                    Intent c = new Intent(FriendsActivity.this, ProfileActivity.class);
                    startActivity(c);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);







        fNumbersList = (RecyclerView) findViewById(R.id.recyclerfriend);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        fNumbersList.setLayoutManager(layoutManager);

        fNumbersList.setHasFixedSize(true);

        //FriendsAdapter = new FriendsAdapter();
        fNumbersList.setAdapter(FriendsAdapter);



        mDatabase = FirebaseDatabase.getInstance().getReference("Users");
        //nDatabase = FirebaseDatabase.getInstance().getReference("Users/ImNewHere");



        ValueEventListener userListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list = new ArrayList<Users>();

                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    Users myuser = dataSnapshot1.getValue(Users.class);
                    list.add(myuser);

                    //TextView usertv = findViewById(R.id.carduser3);
                    //TextView posttv = findViewById(R.id.cardpost3);
                    // ImageView ppic = findViewById(R.id.cardpic3);
                    //usertv.setText(myuser.getUser());
                    //posttv.setText(myuser.getBio());
                    //ppic.setImageDrawable();
                }
                FriendsAdapter = new FriendsAdapter(FriendsActivity.this, list);
                fNumbersList.setAdapter(FriendsAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        mDatabase.addValueEventListener(userListener);

        BottomNavigationView bottomnav = (BottomNavigationView) findViewById(R.id.navigation);
        bottomnav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = bottomnav.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(false);

       /* mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        ImageView elitistShiba = findViewById(R.id.imageView3);
        elitistShiba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent d = new Intent(FriendsActivity.this, FriendPageActivity.class);
                startActivity(d);
            }
        });

        ImageView minecraftPlayer = findViewById(R.id.imageView4);
        minecraftPlayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {
                Intent e = new Intent(FriendsActivity.this, LoginActivity.class);
                startActivity(e);
            }
        });


        ImageView vrBoi = findViewById(R.id.imageView5);
        vrBoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v3) {
                Intent f = new Intent(FriendsActivity.this, ItemActivity.class);
                startActivity(f);
            }
        });*/


    }
    @Override
    public void onListItemClick(int clickedItemIndex){

    };


}
