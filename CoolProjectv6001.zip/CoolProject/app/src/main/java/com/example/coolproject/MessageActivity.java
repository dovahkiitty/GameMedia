package com.example.coolproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MessageActivity extends AppCompatActivity {

    private EditText mTextMessage;
    String messagetext;
    String key;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_search:
                    //mTextMessage.setText(R.string.title_search);

                    Intent a = new Intent(MessageActivity.this, SearchActivity.class);
                    startActivity(a);
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);

                    Intent b = new Intent(MessageActivity.this, MainActivity.class);
                    startActivity(b);
                    return true;
                case R.id.navigation_profile:
                    //mTextMessage.setText(R.string.title_profile);

                    Intent c = new Intent(MessageActivity.this, ProfileActivity.class);
                    startActivity(c);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        BottomNavigationView bottomnav = (BottomNavigationView) findViewById(R.id.navigation);
        bottomnav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = bottomnav.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(false);


        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Button discardButton = findViewById(R.id.button4);
        discardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(MessageActivity.this, MainActivity.class);
                startActivity(j);
            }
        });

        Button sendButton = findViewById(R.id.button2);
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTextMessage = (EditText) findViewById(R.id.messagepane);
                messagetext = mTextMessage.getText().toString();

                if(!messagetext.equals("")) {

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    final DatabaseReference myRef = database.getReference("Messages");

                    myRef.push().setValue(messagetext);

                    //key = dataSnapshot.getKey();


                    Toast.makeText(getApplicationContext(), "Message sent", Toast.LENGTH_SHORT).show();


                    Intent k = new Intent(MessageActivity.this, MainActivity.class);
                    startActivity(k);
                }
                else
                    Toast.makeText(getApplicationContext(), "Please type a message", Toast.LENGTH_SHORT).show();
            }
        });

        // Toast.makeText(getApplicationContext(),"This will let you create a message to post. Still working on it. The item and friend page activities are done. Click the first user's profile picture or the 'Playing:' text to go to them. The bottom nav bar selects the wrong things in activities other than the main three. Login does not work, however.", Toast.LENGTH_LONG).show();


    }

}
