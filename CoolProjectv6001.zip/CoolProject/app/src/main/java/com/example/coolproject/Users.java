package com.example.coolproject;

public class Users {
    private String user;
    private String email;
    private String profilePic;
    private String bio;
    private String key;


    public Users() {
    }

    public Users(String user, String email, String profilePic, String bio) {
        this.user = user;
        this.email = email;
        this.profilePic = profilePic;
        this.bio = bio;
    }

    public Users(String uname, String mail){
        this.user = uname;
        this.email = mail;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public void setKey(String key){
        this.key = key;
    }

    public String getKey()
    {
        return key;
    }

}
