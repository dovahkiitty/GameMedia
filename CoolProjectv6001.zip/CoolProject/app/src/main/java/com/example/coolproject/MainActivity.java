package com.example.coolproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.BreakIterator;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements Adapter.ListItemClickListener {

    private Adapter mAdapter;
    // private Adapter uAdapter;
    private RecyclerView mNumbersList;
    private Toast mToast;
    ArrayList<Users> list;


    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_search:
                    //mTextMessage.setText(R.string.title_search);

                    Intent a = new Intent(MainActivity.this, SearchActivity.class);
                    startActivity(a);
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_profile:
                    //mTextMessage.setText(R.string.title_profile);

                    Intent b = new Intent(MainActivity.this, ProfileActivity.class);
                    startActivity(b);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNumbersList = (RecyclerView) findViewById(R.id.recycler);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mNumbersList.setLayoutManager(layoutManager);

        mNumbersList.setHasFixedSize(true);

        mAdapter = new Adapter(100, this);
        mNumbersList.setAdapter(mAdapter);

        /*TextView mGamesTextView;
        mGamesTextView = (TextView) findViewById(R.id.gameTextView);*/

        //*************************************************************************
        //write to database
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();
        //final DatabaseReference myRef = database.getReference("Messages");
        //final DatabaseReference myRef2 = database.getReference("Users");
        final RecyclerView recyclerView;
        // myRef.setValue("I love video games!");
        //myRef2.getDatabase();

        //myRef2 = FirebaseDatabase.getInstance().getReference().child(Users);

        recyclerView = (RecyclerView) findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //myRef.addValueEventListener ...

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Users user = dataSnapshot.getValue(Users.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };
        //myRef2.addValueEventListener(new ValueEventListener() {
            /*@Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                list = new ArrayList<Users>();
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                //String value = dataSnapshot.getValue(String.class);
                //Log.d(TAG, "Value is: " + value);
                for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren()){
                    Users u = dataSnapshot1.getValue(Users.class);
                    list.add(u);
                }
               // mAdapter = new uAdapter(MainActivity.this,list);
                recyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                //Log.w(TAG, "Failed to read value.", error.toException());
                //Toast.makeText(MainActivity.this, "oops... something went wrong.", Toast.LENGTH_SHORT).show();
            }


        });*/



        //*****************************************************************************



        BottomNavigationView bottomnav = (BottomNavigationView) findViewById(R.id.navigation);
        bottomnav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Menu menu = bottomnav.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        FloatingActionButton fab = findViewById(R.id.fab);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        fab.setImageResource(R.drawable.ic_baseline_add_24px);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent m = new Intent(MainActivity.this, MessageActivity.class);
                startActivity(m);

                // Toast.makeText(getApplicationContext(),"This will let you create a message to post. Still working on it. The item and friend page activities are done. Click the first user's profile picture or the 'Playing:' text to go to them. The bottom nav bar selects the wrong things in activities other than the main three. Login does not work, however.", Toast.LENGTH_LONG).show();
            }
        } );

       /* ImageView pfp1 = findViewById(R.id.pfp1);
        pfp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FriendPageActivity.class);
                startActivity(i);
            }
        });

        TextView game = findViewById(R.id.textView5);
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(MainActivity.this, ItemActivity.class);
                startActivity(j);
            }
        });*/
    }



    @Override
    public void onListItemClick(int clickedItemIndex) {
        // COMPLETED (11) In the beginning of the method, cancel the Toast if it isn't null
        /*
         * Even if a Toast isn't showing, it's okay to cancel it. Doing so
         * ensures that our new Toast will show immediately, rather than
         * being delayed while other pending Toasts are shown.
         *
         * Comment out these three lines, run the app, and click on a bunch of
         * different items if you're not sure what I'm talking about.
         */
/*        if (mToast != null) {
            mToast.cancel();
        }*/

        // COMPLETED (12) Show a Toast when an item is clicked, displaying that item number that was clicked
        /*
         * Create a Toast and store it in our Toast field.
         * The Toast that shows up will have a message similar to the following:
         *
         *                     Item #42 clicked.
         */
       /* String toastMessage = "Item #" + clickedItemIndex + " clicked.";
        mToast = Toast.makeText(this, toastMessage, Toast.LENGTH_LONG);*/

        // mToast.show();
    }

    @Override
    protected void onStart(){
        super.onStart();

        DatabaseReference gamesRef = mRootRef.child("Games");
        gamesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String text = dataSnapshot.getValue(String.class);
                TextView mGamesTextView;
                mGamesTextView = (TextView) findViewById(R.id.gameTextView);
                mGamesTextView.setText(text);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}