/*
package com.example.coolproject;

import android.support.v7.widget.RecyclerView;

public class uAdapter extends RecyclerView.uAdapter<Adapter.NumberViewHolder> {

}
*/
